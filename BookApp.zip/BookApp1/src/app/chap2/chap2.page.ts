import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap2',
  templateUrl: './chap2.page.html',
  styleUrls: ['./chap2.page.scss'],
})
export class Chap2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

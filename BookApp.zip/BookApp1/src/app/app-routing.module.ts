import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)},
  {
    path: 'chap1',
    loadChildren: () => import('./chap1/chap1.module').then( m => m.Chap1PageModule)
  },
  {
    path: 'chap2',
    loadChildren: () => import('./chap2/chap2.module').then( m => m.Chap2PageModule)
  },
  {
    path: 'chap3',
    loadChildren: () => import('./chap3/chap3.module').then( m => m.Chap3PageModule)
  },
  {
    path: 'toc',
    loadChildren: () => import('./toc/toc.module').then( m => m.TocPageModule)
  },
  {
    path: 'images',
    loadChildren: () => import('./images/images.module').then( m => m.ImagesPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap3',
  templateUrl: './chap3.page.html',
  styleUrls: ['./chap3.page.scss'],
})
export class Chap3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

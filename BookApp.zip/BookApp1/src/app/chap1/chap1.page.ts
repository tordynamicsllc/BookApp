import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap1',
  templateUrl: './chap1.page.html',
  styleUrls: ['./chap1.page.scss'],
})
export class Chap1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
